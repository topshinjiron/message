
    @include('header')
    </head>
    <body>
        @include('header_bar')
        <!-- offcanvas-area -->
        @include('offcanvas')
        <!-- offcanvas-end -->
        <!-- main-area -->
        <main>
        <!-- slider-area -->
        <section id="parallax" class="slider-area slider-bg second-slider-bg d-flex align-items-center justify-content-center fix" style="background-image: url(assets/img/slider/slider_bg.png); background-size: cover;">
            <div class="slider-shape ss-one layer" data-depth="0.10"><img src="/assets/img/slider/slider_shape01.png" alt="shape"></div>
            <div class="slider-shape ss-two layer" data-depth="0.10"><img src="/assets/img/slider/slider_shape02.png" alt="shape"></div>
            <div class="slider-shape ss-three layer" data-depth="0.10"><img src="/assets/img/slider/slider_shape03.png" alt="shape"></div>
            <div class="slider-shape ss-four layer" data-depth="0.10"><img src="/assets/img/slider/slider_shape04.png" alt="shape"></div>
            <div class="single-slider slider-bg d-flex align-items-center">
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-xl-5 col-lg-6 col-md-12">
                            <div class="slider-content s-slider-content mt-100">
                                <h5 data-animation="fadeInUp" data-delay=".4s">Business Potential</h5>
                                <h2 data-animation="fadeInUp" data-delay=".4s">Unlocking Your Business Potential</h2>
                                <p data-animation="fadeInUp" data-delay=".6s">Business consulting is a professional service that provides expert advice and guidance to businesses in various areas such </p>
                                <div class="slider-btn mt-30 mb-105">
                                    <a href="contact.html" class="btn ss-btn mr-15" data-animation="fadeInLeft" data-delay=".4s">learn more <i class="fa-regular fa-arrow-right"></i></a>
                                    <span class="h-call-box">
                                        <div class="icon">
                                        <img src="/assets/img/slider/phone-call.png" alt="shape">
                                        </div>
                                        <div class="text">
                                            Need help?
                                            <strong><a href="tel:+13172704509">+1317-270-4509</a></strong>
                                        </div>
                                    </span>

                                </div>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-6 col-md-12 p-relative text-right">
                            <img src="/assets/img/slider/man_header.png" alt="shape">
                        </div>
                    </div>
                </div>
            </div>
        </section>
            <!-- slider-area-end -->
            <!-- service-area -->
            <section class="service-three p-relative fix pt-120">
                <div class="container">
                    <div class="row sbox">
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="services-box mb-30 text-center wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                            <div class="sr-contner">
                                <div class="icon">
                                <img src="/assets/img/icon/sve-icon1.png" alt="icon01">
                                </div>
                                <div class="text">
                                    <h3><a href="services.html">Growth Solutions</a></h3>
                                    <p>Aliquam eros justo, posuerei ini lobortis nonv iverra Sed issmbs deslaoreet augue </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="services-box active mb-30 text-center wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                            <div class="sr-contner">
                            <div class="icon">
                            <img src="/assets/img/icon/sve-icon2.png" alt="icon01">
                            </div>
                        <div class="text">
                                <h3><a href="services.html">Profitability Maximizers</a></h3>
                                <p>Aliquam eros justo, posuerei ini lobortis nonv iverra Sed issmbs deslaoreet augue </p>
                            </div>
                        </div>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="services-box mb-30 text-center wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                            <div class="sr-contner">
                                <div class="icon">
                                    <img src="/assets/img/icon/sve-icon3.png" alt="icon01">
                                </div>
                                <div class="text">
                                    <h3><a href="services.html">Efficiency Enhancers</a></h3>
                                    <p>Aliquam eros justo, posuerei ini lobortis nonv iverra Sed issmbs deslaoreet augue </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="services-box mb-30 text-center wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                            <div class="sr-contner">
                                <div class="icon">
                                    <img src="/assets/img/icon/sve-icon4.png" alt="icon01">
                                </div>
                                <div class="text">
                                    <h3><a href="services.html">Book Keeping</a></h3>
                                    <p>Aliquam eros justo, posuerei ini lobortis nonv iverra Sed issmbs deslaoreet augue </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </section>
            <!-- service-details2-area-end -->
            <!-- about-area -->
            <section class="about-area about-p pt-90 pb-120 p-relative fix">
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="s-about-img p-relative wow fadeInLeft animated" data-animation="fadeInLeft" data-delay=".4s">
                                <img src="/assets/img/features/about_img_01.png" alt="img">
                                <div class="play-about">
                                    <img src="/assets/img/features/play-about.png" alt="img">
                                </div>
                                <div class="about-icon">
                                    <img src="/assets/img/features/ab-ani-02.png" alt="img">
                                </div>
                                <div class="about-icon2">
                                    <img src="/assets/img/features/ab-ani-01.png" alt="img">
                                </div>
                                <div class="about-text second-about">
                                    <span>10</span>
                                    <p>Years of Experience</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="about-content s-about-content wow fadeInRight animated" data-animation="fadeInRight" data-delay=".4s">
                                <div class="about-title second-title pb-25">
                                    <h5>About Us</h5>
                                    <h2>Unlock Your Business Potential Drive Success with</h2>
                                </div>
                                <p>Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum vitae at nam. Netus proin arcu nisl velit et magna euismod congue.Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum </p>
                                <div class="about-content3 mt-30">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <ul class="green">
                                                <li>Performance Improvement Specialists</li>
                                                <li>Problem Solvers Extraordinaire</li>
                                                <li>Business Transformation Consultants</li>
                                                <li>Unlock Opportunities with Strategic Consulting</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <a href="about.html" class="btn ss-btn smoth-scroll mt-15">Read More <i class="fa-regular fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- about-area-end -->
            <!-- service-area -->
            <section class="service pt-120 pb-90 p-relative fix" style="background-image: url(assets/img/bg/services-bg.png); background-size: cover; background-repeat: no-repeat;">
                <div class="container">
                    <div class="row justify-content-center align-items-center mb-50">
                        <div class="col-lg-6 col-md-6">
                            <div class="section-title center-align wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                <h5>LATEST SERVICE</h5>
                                <h2>
                                Expert Consultin Achieve Growth Through
                                </h2>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="section-title center-align wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                            <p>Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum vitae at nam. Netus proin arcu nisl velit et magna euismod</p>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-4 d-none d-lg-block">
                            <a href="about.html" class="btn ss-btn smoth-scroll">Read More <i class="fa-regular fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="row services-active">
                        <div class="col-lg-4">
                            <div class="services-box-05" data-aos="fade-up" data-aos-duration="1000">
                                <div class="services-icons-05">
                                    <img src="/assets/img/icon/seriv-icon1.png" alt="icon01">
                                </div>
                                <div class="services-icon-05">
                                    <img src="/assets/img/bg/services-01.png" alt="icon01">
                                </div>
                                <div class="services-content-05">
                                        <h4> <a href="single-service.html">Strategy Consulting Experts</a></h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="services-box-05" data-aos="fade-up" data-aos-duration="1000">
                                <div class="services-icons-05">
                                    <img src="/assets/img/icon/seriv-icon2.png" alt="icon01">
                                </div>
                                <div class="services-icon-05">
                                    <img src="/assets/img/bg/services-02.png" alt="icon01">
                                </div>
                                <div class="services-content-05">
                                    <h4> <a href="single-service.html">Profitability payable Maximizers </a></h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="services-box-05" data-aos="fade-up" data-aos-duration="1000">
                                <div class="services-icons-05">
                                    <img src="/assets/img/icon/seriv-icon3.png" alt="icon01">
                                </div>
                                <div class="services-icon-05">
                                    <img src="/assets/img/bg/services-03.png" alt="icon01">
                                </div>
                                <div class="services-content-05">
                                    <h4> <a href="single-service.html">Business Growth accounts </a></h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="services-box-05" data-aos="fade-up" data-aos-duration="1000">
                                <div class="services-icons-05">
                                    <img src="/assets/img/icon/seriv-icon2.png" alt="icon01">
                                </div>
                                <div class="services-icon-05">
                                    <img src="/assets/img/bg/services-02.png" alt="icon01">
                                </div>
                                <div class="services-content-05">
                                    <h4> <a href="single-service.html">CCTV & Video Surveillance</a></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- service-details2-area-end -->
            <!-- scrollbox-area -->
            <div class="scrollbox2 fix">
                <div class="scrollbox scrollbox--secondary scrollbox--reverse">
                    <div class="scrollbox__item"><i class="fa-regular fa-star-of-life"></i> Business Growth</div>
                    <div class="scrollbox__item"><span><i class="fa-regular fa-star-of-life"></i> Profitability Maximizers</span></div>
                    <div class="scrollbox__item"><i class="fa-regular fa-star-of-life"></i> Business Growth</div>
                    <div class="scrollbox__item"><span><i class="fa-regular fa-star-of-life"></i> Profitability Maximizers</span></div>
                    <div class="scrollbox__item"><i class="fa-regular fa-star-of-life"></i> Business Growth</div>
                    <div class="scrollbox__item"><span><i class="fa-regular fa-star-of-life"></i> Profitability Maximizers</span></div>
                </div>
            </div>
            <!-- scrollbox-area-end -->
            <!-- work-process-area -->
            <section class="work-process pt-120 pb-120 p-relative fix">
                <div class="container">
                    <div class="row justify-content-center align-items-center mb-50">
                        <div class="col-lg-6 col-md-12">
                            <div class="section-title center-align text-center wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                <h5>Work Process</h5>
                                <h2>
                                Optimize Your Business for Maximum Success
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="work-process-box">
                                <ul>
                                    <li>
                                        <div class="work-process-box">
                                            <div class="arrow-icon">
                                                <img src="/assets/img/icon/process-arrow.png" alt="icon01">
                                            </div>
                                            <div class="icon">
                                                <img src="/assets/img/icon/process-icon-01.png" alt="icon01">
                                            </div>
                                            <div class="text">
                                                <h3><a href="services.html">Strategize</a></h3>
                                                <p>Designer Lorem ipsum dolor sit amet is consectetur adipiscing our here  </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="work-process-box">
                                            <div class="arrow-icon">
                                                <img src="/assets/img/icon/process-arrow.png" alt="icon01">
                                            </div>
                                            <div class="icon">
                                                <img src="/assets/img/icon/process-icon-02.png" alt="icon01">
                                            </div>
                                            <div class="text">
                                                <h3><a href="services.html"> Sketch</a></h3>
                                                <p>Designer Lorem ipsum dolor sit amet is consectetur adipiscing our here </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="work-process-box">
                                            <div class="arrow-icon">
                                                <img src="/assets/img/icon/process-arrow.png" alt="icon01">
                                            </div>
                                            <div class="icon">
                                                <img src="/assets/img/icon/process-icon-03.png" alt="icon01">
                                            </div>
                                            <div class="text">
                                                <h3><a href="services.html">Code</a></h3>
                                                <p>Designer Lorem ipsum dolor sit amet is consectetur adipiscing our here </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="work-process-box">
                                            <div class="arrow-icon">
                                                <img src="/assets/img/icon/process-arrow.png" alt="icon01">
                                            </div>
                                            <div class="icon">
                                                <img src="/assets/img/icon/process-icon-04.png" alt="icon01">
                                            </div>
                                            <div class="text">
                                                <h3><a href="services.html">Plan</a></h3>
                                                <p>Designer Lorem ipsum dolor sit amet is consectetur adipiscing our here </p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- work-process-area-end -->
            <!-- frequently-area -->
            <section class="faq-area pt-120 pb-95 p-relative fix" style="background:#FEF7F6;">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="section-title wow fadeInLeft animated pr-80" data-animation="fadeInDown animated" data-delay=".2s">
                                <h5>FAQ</h5>
                                <h2>Boost Your Business with the Expert Advice</h2>
                                <p>Dictum ultrices porttitor amet nec sollicitudin mi molestie adipiscing netus. Lorem at ac ut morbi ullamcorper molestie lacus. Euismod nulla viverra condimentum Dictum ultrices porttitor amet</p>
                                <a href="about.html" class="btn ss-btn smoth-scroll mt-20">Learn More <i class="fa-regular fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="faq-wrap mt-30 pr-30 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                <div class="accordion" id="accordionExample">
                                    <div class="card">
                                        <div class="card-header" id="headingThree">
                                            <h2 class="mb-0">
                                                <button class="faq-btn" type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapseThree"  >
                                                What types of businesses can benefit from?
                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapseThree" class="collapse show"
                                            data-bs-parent="#accordionExample">
                                            <div class="card-body">
                                                Dictum ultrices porttitor amet nec sollicitudin mi molestie adipiscing netus. Lorem at ac ut morbi ullamcorper molestie lacu
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" id="headingOne">
                                            <h2 class="mb-0">
                                                <button class="faq-btn collapsed" type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapseOne"  >
                                                What factors should businesses consider when?
                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapseOne" class="collapse" data-bs-parent="#accordionExample">
                                            <div class="card-body">
                                                Dictum ultrices porttitor amet nec sollicitudin mi molestie adipiscing netus. Lorem at ac ut morbi ullamcorper molestie lacu
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" id="headingTwo">
                                            <h2 class="mb-0">
                                                <button class="faq-btn collapsed" type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapseTwo"  >
                                                How can consulting help operations?
                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse" data-bs-parent="#accordionExample">
                                            <div class="card-body">
                                            Dictum ultrices porttitor amet nec sollicitudin mi molestie adipiscing netus. Lorem at ac ut morbi ullamcorper molestie lacu
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header">
                                            <h2 class="mb-0">
                                                <button class="faq-btn collapsed" type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapseFour"  >
                                                How do consultants and analyze data?
                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapseFour" class="collapse" data-bs-parent="#accordionExample">
                                            <div class="card-body">
                                                Dictum ultrices porttitor amet nec sollicitudin mi molestie adipiscing netus. Lorem at ac ut morbi ullamcorper molestie lacu
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- frequently-area-end -->
            <!-- pricing-area -->
            <section id="pricing" class="pricing-area pt-120 pb-60 fix p-relative">
                <div class="container">
                    <div class="row justify-content-center align-items-end mb-50">
                        <div class="col-lg-5 col-md-12">
                            <div class="section-title center-align  wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                <h5>Pricing action</h5>
                                <h2>
                                The artistry behind successful brands
                                </h2>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-12 text-right">
                            <ul class="nav nav-tabs">
                                <li>
                                    <span class="active" id="home-tab" data-bs-toggle="tab" data-bs-target="#voverview" role="tab">Monthly</span>
                                </li>
                                <li>
                                    <span id="profile-tab" data-bs-toggle="tab" data-bs-target="#degre" role="tab">Yearly</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="row justify-content-center align-items-center">
                        <div class="col-lg-12 col-md-12">
                            <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="voverview" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-4 col-md-6">
                                        <div class="pricing-box mb-60 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                        <div class="pricing-head">
                                            <div class="price-count">
                                                <h2>$19 <strong>/ Month</strong></h2>
                                            </div>
                                            <h3>Bronze Package</h3>
                                            <!-- <p>Lorem Ipsum is simply dummy text of the printing not real</p> -->
                                            <hr>
                                        </div>
                                        <div class="pricing-body mt-20 mb-30 text-left">
                                            <ul>
                                                <li>Access to database full of player and coaches contacts around the country, mostly focused in Indiana and in the Midwest</li>
                                                <li>Monthly reports and information on players across the Midwest from the Senior class.</li>
                                                <li>12 reports a year, 1 a month.</li>
                                                <li>D2, NAIA, D3’s recommended</li>
                                            </ul>
                                        </div>
                                        <div class="pricing-btn">
                                            <a href="contact.html" class="btn ss-btn">Purchase now <i class="fa-regular fa-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="pricing-box active mb-60 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                    <div class="pricing-head">
                                        <div class="price-count">
                                            <h2>$29 <strong>/ Month</strong></h2>
                                        </div>
                                        <h3>Silver Package</h3>
                                        <!-- <p>Lorem Ipsum is simply dummy text of the printing not real</p> -->
                                        <hr>
                                    </div>
                                    <div class="pricing-body mt-20 mb-30 text-left">
                                        <ul>
                                            <li>Access to database of player and coaches contact information around the country, most focused in Indiana and in the Midwest.</li>
                                            <li>Monthly reports and information on players across the Midwest from the Junior and Senior classes</li>
                                            <li>15 reports a year, 1 a month for 9 months, biweekly for months May, June, and July.</li>
                                            <li>High level D2’s, LM D1s, and MMs recommended.</li>
                                        </ul>
                                    </div>
                                    <div class="pricing-btn">
                                        <a href="contact.html" class="btn ss-btn">Purchase now <i class="fa-regular fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="pricing-box mb-60 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                        <div class="pricing-head">
                                            <div class="price-count">
                                                <h2>$39 <strong>/ Month</strong></h2>
                                            </div>
                                            <h3>Gold Package</h3>
                                            <!-- <p>Lorem Ipsum is simply dummy text of the printing not real</p> -->
                                            <hr>
                                        </div>
                                        <div class="pricing-body mt-20 mb-30 text-left">
                                            <ul>
                                                <li>Access to database full of player and coaches contacts around the country, mostly focused in Indiana and in the Midwest.</li>
                                                <li>BiWeekly reports and information on players across the Midwest from Freshman, sophomores, juniors and the senior class.</li>
                                                <li>24 reports a year</li>
                                                <li>mid major and high major Division 1 schools recommended</li>
                                            </ul>
                                        </div>
                                        <div class="pricing-btn">
                                        <a href="contact.html" class="btn ss-btn">Purchase now <i class="fa-regular fa-arrow-right"></i></a>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                </div>
                            <div class="tab-pane fade" id="degre" role="tabpanel">
                                <div class="row">
                                <div class="col-lg-4 col-md-6">
                                    <div class="pricing-box mb-60 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                    <div class="pricing-head">
                                        <div class="price-count">
                                            <h2>$150 <strong>/ year</strong></h2>
                                        </div>
                                        <h3>Bronze Package</h3>
                                        <!-- <p>Lorem Ipsum is simply dummy text of the printing not real</p> -->
                                        <hr>
                                    </div>
                                    <div class="pricing-body mt-20 mb-30 text-left">
                                        <ul>
                                            <li>Access to database full of player and coaches contacts around the country, mostly focused in Indiana and in the Midwest</li>
                                            <li>Monthly reports and information on players across the Midwest from the Senior class.</li>
                                            <li>12 reports a year, 1 a month.</li>
                                            <li>D2, NAIA, D3’s recommended</li>
                                        </ul>
                                    </div>
                                    <div class="pricing-btn">
                                    <a href="contact.html" class="btn ss-btn">Purchase now <i class="fa-regular fa-arrow-right"></i></a>
                                    </div>
                                </div>
                                    </div>
                                <div class="col-lg-4 col-md-6">
                                <div class="pricing-box active mb-60 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                        <div class="pricing-head">
                                            <div class="price-count">
                                                <h2>$250 <strong>/ year</strong></h2>
                                            </div>
                                            <h3>Silcer Package</h3>
                                            <!-- <p>Lorem Ipsum is simply dummy text of the printing not real</p> -->
                                            <hr>
                                        </div>

                                        <div class="pricing-body mt-20 mb-30 text-left">
                                            <ul>
                                                <li>Access to database of player and coaches contact information around the country, most focused in Indiana and in the Midwest.</li>
                                                <li>Monthly reports and information on players across the Midwest from the Junior and Senior classes</li>
                                                <li>15 reports a year, 1 a month for 9 months, biweekly for months May, June, and July.</li>
                                                <li>High level D2’s, LM D1s, and MMs recommended.</li>
                                            </ul>
                                            </ul>
                                        </div>


                                        <div class="pricing-btn">
                                        <a href="contact.html" class="btn ss-btn">Purchase now <i class="fa-regular fa-arrow-right"></i></a>
                                        </div>
                                    </div>

                            </div>
                            <div class="col-lg-4 col-md-6">
                            <div class="pricing-box mb-60 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                        <div class="pricing-head">

                                            <div class="price-count">
                                                <h2>$500 <strong>/ year</strong></h2>
                                            </div>
                                            <h3>Gold Package</h3>
                                            <!-- <p>Lorem Ipsum is simply dummy text of the printing not real</p> -->
                                            <hr>
                                        </div>

                                        <div class="pricing-body mt-20 mb-30 text-left">
                                            <ul>
                                                <li>Access to database full of player and coaches contacts around the country, mostly focused in Indiana and in the Midwest.</li>
                                                <li>BiWeekly reports and information on players across the Midwest from Freshman, sophomores, juniors and the senior class.</li>
                                                <li>24 reports a year</li>
                                                <li>mid major and high major Division 1 schools recommended</li>
                                            </ul>
                                        </div>


                                        <div class="pricing-btn">
                                        <a href="contact.html" class="btn ss-btn">Purchase now <i class="fa-regular fa-arrow-right"></i></a>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                            </div>

                    </div>
                    </div>
                </div>
            </section>
            <!-- pricing-area-end -->
            <!-- brand-area -->
            <div class="brand-area pb-120">
                <div class="container">
                    <div class="row brand-active">
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo1.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo2.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo3.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo4.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo5.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo1.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo2.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo3.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo4.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                <img src="/assets/img/brand/b-logo5.png" alt="img">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- brand-area-end -->
                <!-- gallery-area -->
            <section class="gallery-area fix pt-120 pb-120">
                <div class="container">
                    <div class="row mb-50 justify-content-center align-items-end">
                        <div class="col-lg-5 col-md-12">
                            <div class="section-title center-alignwow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                <h5>Latest PORTFOLIO</h5>
                                <h2>
                                Maximize Efficiency and the Profitability
                                </h2>

                            </div>

                        </div>
                        <div class="col-lg-1 col-md-12"></div>
                        <div class="col-lg-6 col-md-12">
                            <div class="section-title center-align wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                    <p>Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum vitae at nam. Netus proin arcu nisl velit et magna euismod congue.Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum </p>
                            </div>

                        </div>
                    </div>
                    </div>
                    <div class="container-fluid">
                    <div class="row portfolio-active">
                    <div class="col-lg-4 col-md-12 mb-30">
                        <a href="projects-detail.html">
                                <figure class="gallery-image">
                                <img src="/assets/img/gallery/protfolio-img01.png" alt="img" class="img">
                                    <figcaption>
                                        <div class="icon"><img src="/assets/img/gallery/g-btn.png" alt="img" class="img">      </div>
                                        <div class="text">
                                            <h4>Business Potential</h4>
                                            <span>Business Intelligence</span>
                                        </div>
                                    </figcaption>
                                </figure>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 mb-30">
                        <a href="projects-detail.html">
                                <figure class="gallery-image">
                                <img src="/assets/img/gallery/protfolio-img02.png" alt="img" class="img">
                                <figcaption>
                                        <div class="icon"><img src="/assets/img/gallery/g-btn.png" alt="img" class="img">      </div>
                                        <div class="text">
                                            <h4>Business Potential</h4>
                                            <span>Business Intelligence</span>
                                        </div>
                                    </figcaption>
                                </figure>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-12 mb-30">
                            <a href="projects-detail.html">
                                <figure class="gallery-image">
                                <img src="/assets/img/gallery/protfolio-img03.png" alt="img" class="img">
                                <figcaption>
                                        <div class="icon"><img src="/assets/img/gallery/g-btn.png" alt="img" class="img">      </div>
                                        <div class="text">
                                        <h4>Business Potential</h4>
                                            <span>Business Intelligence</span>
                                        </div>
                                    </figcaption>
                                </figure>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 mb-30">
                        <a href="projects-detail.html">
                                <figure class="gallery-image">
                                <img src="/assets/img/gallery/protfolio-img04.png" alt="img" class="img">
                                <figcaption>
                                        <div class="icon"><img src="/assets/img/gallery/g-btn.png" alt="img" class="img">      </div>
                                        <div class="text">
                                        <h4>Business Potential</h4>
                                            <span>Business Intelligence</span>
                                        </div>
                                    </figcaption>
                                </figure>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 mb-30">
                            <a href="projects-detail.html">
                                <figure class="gallery-image">
                                <img src="/assets/img/gallery/protfolio-img05.png" alt="img" class="img">
                                <figcaption>
                                        <div class="icon"><img src="/assets/img/gallery/g-btn.png" alt="img" class="img">      </div>
                                        <div class="text">
                                            <h4>Business Potential</h4>
                                            <span>Business Intelligence</span>
                                        </div>
                                    </figcaption>
                                </figure>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-12 mb-30">
                            <a href="projects-detail.html">
                                <figure class="gallery-image">
                                <img src="/assets/img/gallery/protfolio-img03.png" alt="img" class="img">
                                <figcaption>
                                        <div class="icon"><img src="/assets/img/gallery/g-btn.png" alt="img" class="img">      </div>
                                        <div class="text">
                                            <h4>Business Potential</h4>
                                            <span>Business Intelligence</span>
                                        </div>
                                    </figcaption>
                                </figure>
                            </a>
                        </div>
                    </div>
                </div>
            </section>
            <!-- gallery-area-end -->
            <!-- newslater-area -->
            <section class="newslater-area wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                <div class="container" style="background-image: url(assets/img/bg/newslater-bg.png); background-repeat: no-repeat; background-size: cover;">
                <div class="row align-items-center">
                    <div class="col-xl-1 col-lg-1 col-md-1"></div>
                    <div class="col-xl-5 col-lg-5 col-md-4">
                        <div class="section-title">
                                <h2>Revenue Generation the Innovators Advisors</h2>
                            </div>
                            </div>
                    <div class="col-xl-6 col-lg-6 col-md-6">
                            <form name="ajax-form" id="contact-form4" action="#" method="post" class="contact-form newslater">
                            <div class="form-group">
                                <input class="form-control" id="email2" name="email" type="email" placeholder="Email Address..." value="" required="">
                                <button type="submit" class="btn btn-custom" id="send2">Subscribe Now</button>
                            </div>

                            </form>
                        </div>

                    </div>
                </div>
            </section>
            <!-- newslater-aread-end -->
        <!-- team-area -->
            <section id="team" class="team-area fix p-relative pt-120 pb-90">
                <div class="container">

                <div class="row justify-content-center align-items-center">
                            <div class="col-lg-6 col-md-8">
                                <div class="section-title p-relative text-center mb-50 wow fadeInUp  animated" data-animation="fadeInUp" data-delay=".4s">
                                <h5>Our team member</h5>
                                <h2>
                                Navigate Challenges with Consulting Expertise
                                </h2>
                            </div>
                            </div>

                        </div>
                <div class="row team-active">
                        <div class="col-xl-3 col-lg-3">
                            <div class="single-team mb-30" >
                                <div class="team-thumb">
                                    <div class="brd">
                                        <img src="/assets/img/team/team01.png" alt="img">
                                        <div class="team-social">
                                                <a href="#" class="share-alt"><i class="fal fa-share-alt"></i></a>
                                                <ul>

                                                    <li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                                    <li> <a href="#"><i class="fab fa-twitter"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                                </ul>
                                            </div>
                                    </div>
                                    <div class="team-info">
                                        <h4><a href="team-single.html">H.Alexander Anna</a></h4>
                                        <p>Managing Director</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-xl-3 col-lg-3">
                            <div class="single-team mb-30" >
                                <div class="team-thumb">
                                    <div class="brd">
                                        <img src="/assets/img/team/team02.png" alt="img">
                                        <div class="team-social">
                                                <a href="#" class="share-alt"><i class="fal fa-share-alt"></i></a>
                                                <ul>

                                                    <li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                                    <li> <a href="#"><i class="fab fa-twitter"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                                </ul>
                                            </div>
                                    </div>
                                    <div class="team-info">
                                        <h4><a href="team-single.html">Elizabeth Joseph</a></h4>
                                        <p>Managing Director</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-xl-3 col-lg-3">
                            <div class="single-team mb-30" >
                                <div class="team-thumb">
                                    <div class="brd">
                                        <img src="/assets/img/team/team03.png" alt="img">
                                        <div class="team-social">
                                                <a href="#" class="share-alt"><i class="fal fa-share-alt"></i></a>
                                                <ul>

                                                    <li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                                    <li> <a href="#"><i class="fab fa-twitter"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                                </ul>
                                            </div>
                                    </div>
                                    <div class="team-info">
                                        <h4><a href="team-single.html">Benjamin Evelyn</a></h4>
                                        <p>Designer</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3">
                            <div class="single-team mb-30" >
                                <div class="team-thumb">
                                    <div class="brd">
                                        <img src="/assets/img/team/team04.png" alt="img">
                                        <div class="team-social">
                                                <a href="#" class="share-alt"><i class="fal fa-share-alt"></i></a>
                                                <ul>

                                                    <li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                                    <li> <a href="#"><i class="fab fa-twitter"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                                </ul>
                                            </div>
                                    </div>
                                    <div class="team-info">
                                        <h4><a href="team-single.html">Jack Martin</a></h4>
                                        <p>Designer</p>

                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3">
                            <div class="single-team mb-30" >
                                <div class="team-thumb">
                                    <div class="brd">
                                        <img src="/assets/img/team/team01.jpg" alt="img">
                                        <div class="team-social">
                                                <a href="#" class="share-alt"><i class="fal fa-share-alt"></i></a>
                                                <ul>
                                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                                    <li> <a href="#"><i class="fab fa-twitter"></i></a></li>
                                                </ul>
                                            </div>
                                    </div>
                                    <div class="team-info">
                                        <h4><a href="team-single.html">Kristal Leo</a></h4>
                                        <p>Designer</p>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </section>
            <!-- team-area-end -->
            <!-- contact-area -->
            <section class="contact-area pt-120 pb-120 p-relative fix">
                <div class="container">
                    <div class="row">
                    <div class="col-lg-6">
                            <div class="contact-bg02">
                            <div class="section-title wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                <h5>STAY CONNECTED </h5>
                                <h2>
                                Boost Your Business with Expert Advice
                                </h2>
                            </div>
                        <form action="mail.php" method="post" class="contact-form mt-30 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                            <div class="row">
                            <div class="col-lg-6">
                                <div class="contact-field p-relative c-name mb-20">
                                    <input type="text" id="firstn" name="firstn" placeholder="First Name" required>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="contact-field p-relative c-subject mb-20">
                                    <input type="text" id="email" name="email" placeholder="Email" required>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="contact-field p-relative c-subject mb-20">
                                    <input type="text" id="phone" name="phone" placeholder="Phone No." required>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="contact-field p-relative c-message mb-30">
                                    <textarea name="message" id="message" cols="30" rows="10" placeholder="Write comments"></textarea>
                                </div>
                                <div class="slider-btn">
                                    <button class="btn ss-btn" data-animation="fadeInRight" data-delay=".8s"><span>Submit Now</span></button>
                                </div>
                            </div>
                            </div>

                    </form>

                            </div>
                        </div>
                        <div class="col-lg-6">
                        <div class="contact-img2">
                            <img src="/assets/img/bg/contact-img.png" alt="img">
                            <div class="about-text second-about">
                                    <span>25</span>
                                    <p>Years of Experience</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- contact-area-end -->

            <!-- blog-area -->
            <section id="blog" class="blog-area p-relative fix pb-90">
                <div class="container">
                    <div class="row align-items-center mb-50">
                        <div class="col-lg-12 col-md-12">
                            <div class="section-title text-center wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                <h5>Our Blog</h5>
                                <h2>
                                    Latest Blog & News
                                </h2>
                            </div>
                        </div>

                    </div>
                    <div class="row"  data-aos="fade-up" data-aos-duration="1400">
                    <div class="col-lg-6 col-md-6">
                            <div class="single-post1 mb-30 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                <div class="blog-thumb2">
                                    <a href="blog-details.html"><img src="/assets/img/blog/inner_b4.jpg" alt="img"></a>
                                </div>
                                <div class="blog-content2">
                                    <div class="date-home">
                                    24th March 2023
                                    </div>
                                <div class="b-meta">
                                        <div class="meta-info">
                                        <ul>
                                                <li><i class="fal fa-user"></i> By Admin </li>
                                                <li><i class="fal fa-comments"></i> 3 Comments</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <h4><a href="blog-details.html">Business analytics utilizes data and statistical methods</a></h4>
                                    <p>Business consulting involves providing man expert advice and guidance Informatio ourServices information</p>
                                    <a href="about.html" class="btn ss-btn smoth-scroll mt-15">Read More <i class="fa-regular fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="single-post1 mb-30 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                <div class="blog-thumb2">
                                    <a href="blog-details.html"><img src="/assets/img/blog/inner_b5.jpg" alt="img"></a>
                                </div>
                                <div class="blog-content2">
                                    <div class="date-home">
                                        24th March 2023
                                    </div>
                                    <div class="b-meta">
                                        <div class="meta-info">
                                            <ul>
                                                <li><i class="fal fa-user"></i> By Admin </li>
                                                <li><i class="fal fa-comments"></i> 3 Comments</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <h4><a href="blog-details.html">Business with Expert Advice the Challenges Consulting </a></h4>
                                    <p>Business consulting involves providing man expert advice and guidance Informatio ourServices information</p>
                                    <a href="about.html" class="btn ss-btn smoth-scroll mt-15">Read More <i class="fa-regular fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- blog-area-end -->
            <!-- map-area-end -->
            <div class="map fix" style="background: #f5f5f5;">
                <div class="container-flud">

                    <div class="row">
                        <div class="col-lg-12">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d212867.83634504632!2d-112.24455686962897!3d33.52582710700138!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x872b743829374b03%3A0xabaac255b1e43fbe!2sPlexus%20Worldwide!5e0!3m2!1sen!2sin!4v1618567685329!5m2!1sen!2sin" width="600" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
            <!-- map-area-end -->

        </main>
        <!-- main-area-end -->
        @include('footer')
