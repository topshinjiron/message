
        <!-- footer -->
        <footer class="footer-bg footer-p" style="background-image: url(assets/img/bg/footer-bg.png);">
            <div class="footer-top-heiding">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-5">
                            <div class="section-title">
                                <h2>Have A Query?</h2>
                            </div>
                        </div>
                         <div class="col-lg-7">
                           <div class="footer-cta">
                                <ul>
                                   <li>
                                      <div class="call-box">
                                         <div class="icon">
                                            <i class="fa-regular fa-phone"></i>
                                         </div>
                                         <div class="text">
                                            <strong>Call Us: <a href="tel:+13172704509">+13172704509</a></strong>
                                         </div>
                                      </div>
                                   </li>
                                   <li>
                                      <div class="call-box">
                                         <div class="icon">
                                           <i class="fa-regular fa-envelope"></i>
                                         </div>
                                         <div class="text">
                                            <strong>Mail Us: <a href="mailto:kaelenbrown30@gmail.com"> kaelenbrown30@gmail.com  </a></strong>
                                         </div>
                                      </div>
                                   </li>
                                </ul>
                             </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="footer-top  pt-50 pb-30">
                <div class="container">
                    <div class="row justify-content-between">

                        <div class="col-xl-3 col-lg-3 col-sm-6">
                            <div class="footer-widget mb-30" data-aos="fade-up" data-aos-duration="1000">
                                <div class="f-widget-title">
                                    <h2> <img src="/assets/img/logo/f_logo.png" alt="img"></h2>
                                </div>
                                <div class="f-contact pr-10">
                                     <p>Lorem Ipsum is simply is dumiomy is text Lorem Ipsum is simply</p>
                                    <ul class="mt-30">
                                    <li>
                                        <div class="icon"> <i class="icon fal fa-location-dot"></i> <strong>Address</strong> </div>
                                        <span>6391 Elgin St. Celina, Delaware 10299</span>
                                    </li>
                                   <li>
                                       <div class="icon"><i class="icon fal fa-envelope"></i> <strong>Email</strong></div>

                                        <span>
                                            <a href="mailto:michelle.rivera@example.com">michelle.rivera@example.com</a>
                                       </span>
                                    </li>


                                </ul>
                                    </div>
                            </div>
                        </div>
						<div class="col-xl-3 col-lg-3 col-sm-6">
                            <div class="footer-widget mb-30" data-aos="fade-up" data-aos-duration="1400">
                                <div class="f-widget-title">
                                    <h2>Services</h2>
                                </div>
                                <div class="footer-link">
                                    <ul>
                                        <li><a href="index.html">Business Growth Solutions</a></li>
                                        <li><a href="about.html"> Profitability Maximizers</a></li>
                                        <li><a href="services.html"> Efficiency Enhancers </a></li>
                                        <li><a href="contact.html"> Problem Solvers Extraordinaire</a></li>
                                        <li><a href="blog.html">Tranquil Haven Designs </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-sm-6">
                            <div class="footer-widget mb-30" data-aos="fade-up" data-aos-duration="1800">
                                <div class="f-widget-title">
                                    <h2>Latest Post</h2>
                                </div>
                                <div class="recent-blog-footer">
                                    <ul>
                                        <li>
                                            <div class="text"> <a href="#">Nothing impossble to need hard work</a>
                                            <span>7 March, 2023</span></div>
                                        </li>

                                        <li>
                                            <div class="text"> <a href="#">Nothing impossble to need hard work</a>
                                            <span>7 March, 2023</span></div>
                                        </li>

                                    </ul>


                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-3 col-sm-6">
                            <div class="footer-widget mb-30" data-aos="fade-up" data-aos-duration="1800">
                                <div class="f-widget-title">
                                    <h2>Latest Post</h2>
                                </div>
                                 <p>Pellentesque quis volutpat odio, rhoncus tempor tellus. Proin condimentum turpis.</p>
                                 <!-- form -->
                                    <form name="ajax-form" id="contact-form4" action="https://formsubmit.io/send/90aa5128-c301-47bf-ae81-794fa4c07dda" method="post" class="contact-form  newslater footer-newlater">
                                       <div class="form-group">
                                          <input class="form-control" id="email2" name="email" type="email" placeholder="Your email" value="" required="">
                                          <button type="submit" class="btn btn-custom" id="send2"><i class="fad fa-paper-plane"></i></button>
                                       </div>
                                       <!-- /Form-email -->
                                    </form>
                                    <!-- /form -->
                                    <div class="footer-social mt-10">
                                         <h3>Follow Us</h3>
                                        <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                                        <a href="https://www.instagram.com/swish_strategies"><i class="fab fa-instagram"></i></a>
                                        <a href="https://www.twitter.com/swishstrategies"><i class="fab fa-twitter"></i></a>
                                    </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="copyright-wrap">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                          Copyright © Maximix 2024 . All rights reserved.
                        </div>
                       <div class="col-lg-6 text-right text-xl-right">
                           <ul>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms Of Service</a></li>
                                <li><a href="#">Legal</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer-end -->

		<!-- JS here -->
        <script src="/assets/js/vendor/modernizr-3.5.0.min.js"></script>
        <script src="/assets/js/vendor/jquery-3.6.0.min.js"></script>
        <script src="/assets/js/popper.min.js"></script>
        <script src="/assets/js/bootstrap.min.js"></script>
        <script src="/assets/js/slick.min.js"></script>
        <script src="/assets/js/ajax-form.js"></script>
        <script src="/assets/js/paroller.js"></script>
        <script src="/assets/js/wow.min.js"></script>
        <script src="/assets/js/js_isotope.pkgd.min.js"></script>
        <script src="/assets/js/imagesloaded.min.js"></script>
        <script src="/assets/js/parallax.min.js"></script>
        <script src="/assets/js/jquery.waypoints.min.js"></script>
        <script src="/assets/js/jquery.counterup.min.js"></script>
        <script src="/assets/js/jquery.scrollUp.min.js"></script>
        <script src="/assets/js/jquery.meanmenu.min.js"></script>
        <script src="/assets/js/parallax-scroll.js"></script>
        <script src="/assets/js/swiper.min.js"></script>
        <script src="/assets/js/jquery.magnific-popup.min.js"></script>
        <script src="/assets/js/element-in-view.js"></script>
        <script src="/assets/js/main.js"></script>
    </body>
</html>
