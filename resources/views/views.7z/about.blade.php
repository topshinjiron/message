
@include('header')
    </head>
    <body>
        @include('header_bar')
        <!-- header-end -->
         <!-- offcanvas-area -->
        @include('offcanvas')
        <!-- offcanvas-end -->
        <!-- main-area -->
        <main>
            <!-- breadcrumb-area -->
            <section class="breadcrumb-area d-flex align-items-center" style="background-image:url(assets/img/bg/bdrc-bg.jpg)">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-12 col-lg-12">
                            <div class="breadcrumb-wrap text-left">
                                <div class="breadcrumb-title">
                                    <h2>About</h2>
                                    <p class="text-white">We are a NCAA certified scouting and consulting service for coaches and players of all levels with experience working with and for the Nike EYBL, Pangos AA camp, USA Basketball, Crossroads Elite Camp, and Indy Heat of the Nike EYBL</p>
                                    <div class="breadcrumb-wrap">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb">
                                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                                <li class="breadcrumb-item active" aria-current="page">About</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- breadcrumb-area-end -->
              <!-- about-area -->
            <section class="about-area about-p pt-90 pb-120 p-relative fix">
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="about-content s-about-content mb-50 wow fadeInRight animated" data-animation="fadeInRight" data-delay=".4s">
                                <div class="about-title second-title pb-25">
                                    <h5>About Us</h5>
                                    <h2>Unlock Your Business Potential Drive Success with</h2>
                                </div>
                                <p>Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum vitae at nam. Netus proin arcu nisl velit et magna euismod congue.Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum </p>
                                <div class="about-content3 mt-30">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <ul class="green">
                                                <li>Performance Improvement Specialists</li>
                                                <li>Problem Solvers Extraordinaire</li>
                                                <li>Business Transformation Consultants</li>
                                                <li>Unlock Opportunities with Strategic Consulting</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <a href="about.html" class="btn ss-btn smoth-scroll mt-15">Read More <i class="fa-regular fa-arrow-right"></i></a>
                            </div>
                        </div>
                         <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="s-about-img p-relative wow fadeInLeft animated" data-animation="fadeInLeft" data-delay=".4s">
                                <img src="/assets/img/features/about_img_04.png" alt="img">
                                  <div class="about-icon about-icon5">
                                     <img src="/assets/img/features/ab-ani-05.png" alt="img">
                                </div>
                                <div class="about-text second-about second-about2">
                                    <span>10</span>
                                    <p>Years of Experience</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- about-area-end -->
              <!-- choose-area -->
            <section class="about-area about-p pt-120 pb-120 p-relative fix" style="background: #0E2453;">
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="s-about-img p-relative wow fadeInLeft animated" data-animation="fadeInLeft" data-delay=".4s">
                                <img src="/assets/img/features/about_img_02.png" alt="img">
                                <div class="about-icon3">
                                    <img src="/assets/img/features/ab-ani-03.png" alt="img">
                                </div>
                                <div class="about-icon4">
                                    <img src="/assets/img/features/ab-ani-04.png" alt="img">
                                </div>
                            </div>
                        </div>
					    <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="about-content2 s-about-content wow fadeInRight animated" data-animation="fadeInRight" data-delay=".4s">
                                <div class="about-title second-title pb-25">
                                    <h5>Why choose us</h5>
                                    <h2>Unlock Your Business Potential Drive Success with</h2>
                                </div>
                                <p>Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum vitae at nam. Netus proin arcu nisl velit et magna euismod congue.Lorem ipsum dolor sit amet consectetur. Augue ante turpis cras condimentum </p>

                                <div class="about-content2 mt-30">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="about-box about-box2 mb-30">
                                                <div class="icon"><img src="/assets/img/features/about-icon-05.png" alt="img"></div>
                                                <div class="text"><h4>Level Up</h4></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="about-box about-box2 mb-30">
                                                <div class="icon"><img src="/assets/img/features/about-icon-06.png" alt="img"></div>
                                                <div class="text"><h4>Online Secure</h4></div>
                                            </div>
                                        </div>
                                    <div class="col-lg-6 col-md-12">
                                            <div class="about-box about-box2 mb-30">
                                                <div class="icon"><img src="/assets/img/features/about-icon-07.png" alt="img"></div>
                                                <div class="text"><h4>Threat Ahead</h4></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="about-box about-box2 mb-30">
                                                <div class="icon"><img src="/assets/img/features/about-icon-08.png" alt="img"></div>
                                                <div class="text"><h4>Trust Secure</h4></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- choose-area-end -->
             <!-- testimonial-area -->
            <section id="testimonial" class="testimonial-area pb-90  p-relative fix">
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                         <div class="col-lg-7">
                              <div class="section-title section-title3 text-center mb-50 wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                  <h5>Clients talk!</h5>
                                <h2>Unlock the potential of your finances with our accounting services</h2>
                            </div>
                        </div>
                      </div>
                    </div>
                     <div class="container" style="background-image: url(assets/img/bg/test-bg2.png); background-repeat: no-repeat;">
                        <div class="row">
                        <div class="col-lg-3"></div>
                        <div class="col-lg-9">
                            <div class="testimonial-active2 wow fadeInUp animated" data-animation="fadeInUp" data-delay=".4s">
                                <div class="single-testimonial">
                                    <div class="qt-img">
                                        <img src="/assets/img/testimonial/qt-icon.png" alt="img">
                                    </div>
                                     <p>Financial planners help people to gain knowledge aboutw toio invest and save their money in the most efficient way ever. Many people all across the coun use them Financial planners help people Financial planners help people</p>
                                     <div class="testi-author mb-20">
                                        <div class="img"><img src="/assets/img/testimonial/testi_avatar.png" alt="img"></div>
                                        <div class="ta-info">
                                             <h6>Miranda H. Halim</h6>
                                            <span>Head Of Idea</span>
                                        </div>
                                    </div>

                                </div>
                              <div class="single-testimonial">
                                    <div class="qt-img">
                                        <img src="/assets/img/testimonial/qt-icon.png" alt="img">
                                    </div>
                                     <p>Financial planners help people to gain knowledge aboutw toio invest and save their money in the most efficient way ever. Many people all across the coun use them Financial planners help people Financial planners help people</p>
                                     <div class="testi-author mb-20">
                                        <div class="img"><img src="/assets/img/testimonial/testi_avatar.png" alt="img"></div>
                                        <div class="ta-info">
                                             <h6>Miranda H. Halim</h6>
                                            <span>Head Of Idea</span>
                                        </div>
                                    </div>

                                </div>
                              <div class="single-testimonial">
                                    <div class="qt-img">
                                        <img src="/assets/img/testimonial/qt-icon.png" alt="img">
                                    </div>
                                     <p>Financial planners help people to gain knowledge aboutw toio invest and save their money in the most efficient way ever. Many people all across the coun use them Financial planners help people Financial planners help people</p>
                                     <div class="testi-author mb-20">
                                        <div class="img"><img src="/assets/img/testimonial/testi_avatar.png" alt="img"></div>
                                        <div class="ta-info">
                                             <h6>Miranda H. Halim</h6>
                                            <span>Head Of Idea</span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- testimonial-area-end -->
             <!-- counter-area -->
         <div class="counter-area p-relative" style="background-image: url(assets/img/bg/counter-bg2.png); background-repeat: no-repeat; background-size: cover;">
            <div class="container">
               <div class="row p-relative">
                  <div class="col-lg-3 col-md-6 col-sm-12">
                     <div class="single-counter single-counter2 mb-30">
                        <div class="counter p-relative wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                           <div class="text">
                                <p>Winning award</p>
                              <span class="count">200</span><sub>+</sub>

                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-12">
                     <div class="single-counter single-counter2 mb-30">
                        <div class="counter p-relative wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                           <div class="text">
                               <p>Project Completed</p>
                              <span class="count">800</span><sub>+</sub>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-12">
                     <div class="single-counter single-counter2 mb-30">
                        <div class="counter p-relative wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                           <div class="text">
                               <p>Happy Clients</p>
                              <span class="count">220</span><sub>+</sub>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-12">
                     <div class="single-counter single-counter2 mb-30">
                        <div class="counter p-relative wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                           <div class="text">
                                <p>Team Members</p>
                              <span class="count">100</span><sub>+</sub>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- counter-area-end -->
             <!-- work-process-area -->
            <section class="work-process pt-120 pb-120 p-relative fix">
                <div class="container">
                     <div class="row justify-content-center align-items-center mb-50">
                        <div class="col-lg-6 col-md-12">
                            <div class="section-title center-align text-center wow fadeInDown animated" data-animation="fadeInDown" data-delay=".4s">
                                <h5>Work Process</h5>
                                <h2>
                                  Optimize Your Business for Maximum Success
                                </h2>

                            </div>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                           <div class="work-process-box">
                              <ul>
                                  <li>
                                      <div class="work-process-box">
                                          <div class="arrow-icon">
                                            <img src="/assets/img/icon/process-arrow.png" alt="icon01">
                                        </div>
                                        <div class="icon">
                                            <img src="/assets/img/icon/process-icon-01.png" alt="icon01">
                                        </div>
                                        <div class="text">
                                            <h3><a href="services.html">Strategize</a></h3>
                                            <p>Designer Lorem ipsum dolor sit amet is consectetur adipiscing our here  </p>
                                        </div>
                                      </div>
                                  </li>
                                  <li>
                                      <div class="work-process-box">
                                           <div class="arrow-icon">
                                            <img src="/assets/img/icon/process-arrow.png" alt="icon01">
                                        </div>
                                        <div class="icon">
                                            <img src="/assets/img/icon/process-icon-02.png" alt="icon01">
                                        </div>
                                        <div class="text">
                                            <h3><a href="services.html"> Sketch</a></h3>
                                            <p>Designer Lorem ipsum dolor sit amet is consectetur adipiscing our here </p>
                                        </div>
                                      </div>
                                  </li>
                                  <li>
                                      <div class="work-process-box">
                                          <div class="arrow-icon">
                                            <img src="/assets/img/icon/process-arrow.png" alt="icon01">
                                        </div>
                                        <div class="icon">
                                            <img src="/assets/img/icon/process-icon-03.png" alt="icon01">
                                        </div>
                                        <div class="text">
                                            <h3><a href="services.html">Code</a></h3>
                                            <p>Designer Lorem ipsum dolor sit amet is consectetur adipiscing our here </p>
                                        </div>
                                      </div>
                                  </li>
                                  <li>
                                      <div class="work-process-box">
                                           <div class="arrow-icon">
                                            <img src="/assets/img/icon/process-arrow.png" alt="icon01">
                                        </div>
                                        <div class="icon">
                                            <img src="/assets/img/icon/process-icon-04.png" alt="icon01">
                                        </div>
                                        <div class="text">
                                            <h3><a href="services.html">Plan</a></h3>
                                            <p>Designer Lorem ipsum dolor sit amet is consectetur adipiscing our here </p>
                                        </div>
                                      </div>
                                  </li>
                              </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- work-process-area-end -->
        </main>
        <!-- main-area-end -->

         <!-- footer -->
    @include('footer')
