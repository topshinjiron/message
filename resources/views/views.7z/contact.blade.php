@include('header')
    </head>
    <body>
        @include('header_bar')
        <!-- header-end -->
        <!-- offcanvas-area -->
        @include('offcanvas')
        <!-- offcanvas-end -->
        <!-- main-area -->
        <main>
            <!-- breadcrumb-area -->
            <section class="breadcrumb-area d-flex align-items-center" style="background-image:url(assets/img/bg/bdrc-bg.jpg)">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-12 col-lg-12">
                            <div class="breadcrumb-wrap text-left">
                                <div class="breadcrumb-title">
                                    <h2>Contact Us</h2>
                                    <div class="breadcrumb-wrap">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb">
                                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                                <li class="breadcrumb-item active" aria-current="page">About</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- breadcrumb-area-end -->

            <!-- contact-area -->
            <section id="contact" class="contact-area3 after-none contact-bg pt-120 pb-90 p-relative fix">
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-lg-5">
                            <div class="section-title center-align text-center mb-50">
                                <h5>Contact Us</h5>
                                <h2>
                                Let us know about your next project
                                </h2>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="contact-info">
                                <div class="single-cta mb-30 wow fadeInUp animated" data-animation="fadeInDown animated" data-delay=".2s">
                                    <div class="f-cta-icon">
                                        <i class="far fa-location-dot"></i>
                                    </div>
                                    <div class="text">
                                        <h5>Office Address</h5>
                                        <p>380 St Kilda Road, Melbourne <br>
                                            VIC 3004, Australia</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="contact-info">
                                <div class="single-cta mb-30 wow fadeInUp animated" data-animation="fadeInDown animated" data-delay=".2s">
                                    <div class="f-cta-icon">
                                        <i class="far fa-phone"></i>
                                    </div>
                                    <div class="text">
                                        <h5>Lets Talk us</h5>
                                        <p>Phone number: +1317-270-4509 <br> Fax: +1317-270-4509</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="contact-info">
                                <div class="single-cta mb-30 wow fadeInUp animated" data-animation="fadeInDown animated" data-delay=".2s">
                                    <div class="f-cta-icon">
                                        <i class="far fa-envelope-open"></i>
                                    </div>
                                    <div class="text">
                                        <h5>Send us email</h5>
                                        <p> <a href="#">kaelenbrown30@gmail.com</a><br><a href="#">kaelenbrown30@gmail.com</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
            <!-- contact-area-end -->
            <!-- contact-area -->
            <section class="contact-area3 after-none contact-bg pt-120 pb-120 p-relative fix" style="background: #FEF7F6;">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 order-2">
                            <div class="contact-bg">
                                <div class="section-title center-align text-center mb-50">
                                    <h5>Get in touch</h5>
                                    <h2>
                                        Custom Inqure Form
                                    </h2>
                                </div>
                                <form action="mail.php" method="post" class="contact-form mt-30 text-center">
                                    <div class="row">
                                    <div class="col-lg-3">
                                        <div class="contact-field p-relative c-name mb-30">
                                            <input type="text" id="firstn" name="firstn" placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="contact-field p-relative c-subject mb-30">
                                            <input type="text" id="email" name="email" placeholder="Email" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="contact-field p-relative c-subject mb-30">
                                            <input type="text" id="phone" name="phone" placeholder="Phone No." required>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="contact-field p-relative c-name mb-30">
                                            <input type="text" id="subject" name="subject" placeholder="Subject" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="contact-field p-relative c-message mb-30">
                                            <textarea name="message" id="message" cols="30" rows="50" placeholder="Write comments"></textarea>
                                        </div>
                                        <div class="slider-btn  text-center">
                                                    <button class="btn ss-btn" data-animation="fadeInRight" data-delay=".8s">Make An Request</button>
                                                </div>
                                    </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact-area-end -->
            <!-- map-area-end -->
            <div class="map fix" style="background: #f5f5f5;">
                <div class="container-flud">
                    <div class="row">
                        <div class="col-lg-12">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d212867.83634504632!2d-112.24455686962897!3d33.52582710700138!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x872b743829374b03%3A0xabaac255b1e43fbe!2sPlexus%20Worldwide!5e0!3m2!1sen!2sin!4v1618567685329!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
            <!-- map-area-end -->

        </main>
        <!-- main-area-end -->

        <!-- footer -->
        @include('footer')
