
         <!-- header -->
         <header class="header-area header-three">
           <div class="header-top second-header d-none d-md-block">
                <div class="container">
                    <div class="row align-items-center">
                         <div class="col-lg-8 col-md-9 d-none d-md-block">
                             <div class="header-cta">
                                <ul>
                                   <li>
                                      <div class="call-box">
                                         <div class="icon">
                                            <i class="fa-regular fa-phone"></i>
                                         </div>
                                         <div class="text">
                                            <strong><a href="tel:+13172704509">+1317-270-4509</a></strong>
                                         </div>
                                      </div>
                                   </li>
                                   <li>
                                      <div class="call-box">
                                         <div class="icon">
                                           <i class="fa-regular fa-envelope"></i>
                                         </div>
                                         <div class="text">
                                            <strong><a href="mailto:kaelenbrown30@gmail.com"> kaelenbrown30@gmail.com  </a></strong>
                                         </div>
                                      </div>
                                   </li>
                                     <li>
                                      <div class="call-box">
                                         <div class="icon">
                                           <i class="fa-regular fa-location-dot"></i>
                                         </div>
                                         <div class="text">
                                            <strong>Cumilla sadar 10299</strong>
                                         </div>
                                      </div>
                                   </li>
                                </ul>
                             </div>
                        </div>
                        <div class="col-lg-4 col-md-3 text-right d-none d-md-block">
                            <div class="header-social">
                                <span>
                                    <!-- <a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a> -->
                                    <a href="https://www.instagram.com/swish_strategies" title="Instagram"><i class="fab fa-instagram"></i></a>
                                    <a href="https://www.twitter.com/swishstrategies" title="Twitter"><i class="fab fa-twitter"></i></a>
                                    <!-- <a href="#" title="Twitter"><i class="fab fa-youtube"></i></a> -->
                                   </span>
                                   <!--  /social media icon redux -->
                            </div>
                        </div>


                    </div>
                </div>
            </div>

			  <div id="header-sticky" class="menu-area">
                <div class="container">
                    <div class="second-menu">
                        <div class="row align-items-center">
                        <div class="col-lg-2 col-md-12">
                            <div class="logo">
                                <a href="index.html"><img src="/assets/img/logo/logo.png" alt="logo"></a>
                            </div>
                        </div>
                           <div class="col-xl-9 col-lg-9">

                                <div class="main-menu">
                                    <nav id="mobile-menu">
                                        <ul>
                                            <li class="has-sub">
												<a href="/">Home</a>
											</li>
                                            <li><a href="about">About Us</a></li>
                                             <li class="has-sub">
                                              <a href="#">Services</a>
                                                <ul>
                                                     <li><a href="#">Services</a></li>
                                                    <li><a href="#">Services Details</a></li>
												</ul>
                                            </li>
                                             <li  class="has-sub">
                                                 <a href="#">Projects</a>
                                                 <ul>
                                                    <li> <a href="#">Projects</a></li>
                                                    <li><a href="#">Project Details</a></li>
                                                </ul>
                                            </li>
                                            <li class="has-sub"><a href="#">Pages</a>
											</li>
                                            <li><a href="contact_us">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                             <div class="col-xl-1 col-lg-1 text-right d-none d-lg-block">
                              <a href="#" class="menu-tigger"><i class="fa-sharp fa-regular fa-bars"></i></a>
                            </div>
                            <div class="col-12">
                                <div class="mobile-menu"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- header-end -->
